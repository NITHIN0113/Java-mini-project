STUDENT MARKS MANAGEMENT SYSTEM
Java Swing GUI + CSV file storage (no MySQL)

Files:
- StudentMarksManagementSystem.java : complete source code
- student_marks.csv : created automatically when the first record is added

Run:
1. Install JDK (Java 8 or later).
2. Open terminal / command prompt in this folder.
3. Compile:
   javac StudentMarksManagementSystem.java
4. Run:
   java StudentMarksManagementSystem

Features:
- Add student marks for Java, Maths and English
- Automatically calculate total, average and grade
- View records in a JTable
- Search by register number or student name
- Update and delete selected records
- Save and reload records from CSV

Grade scale used in this sample:
A+ >= 90, A >= 80, B >= 70, C >= 60, D >= 50, F < 50.
You can change the subject names and grade thresholds if your original project used different rules.
The CSV file is stored in the same working directory from which the program is launched.
