import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.StringJoiner;

public class StudentMarksManagementSystem extends JFrame {
    private static final String FILE_NAME = "student_marks.csv";
    private final DefaultTableModel model = new DefaultTableModel(
        new String[]{"Register No", "Student Name", "Java", "Maths", "English", "Total", "Average", "Grade"}, 0
    ) {
        public boolean isCellEditable(int row, int col) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JTextField regField = new JTextField(12);
    private final JTextField nameField = new JTextField(16);
    private final JTextField javaField = new JTextField(5);
    private final JTextField mathsField = new JTextField(5);
    private final JTextField englishField = new JTextField(5);
    private final JLabel status = new JLabel("Ready");

    public StudentMarksManagementSystem() {
        setTitle("Student Marks Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 620);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JLabel heading = new JLabel("STUDENT MARKS MANAGEMENT SYSTEM", SwingConstants.CENTER);
        heading.setFont(new Font("Arial", Font.BOLD, 23));
        heading.setBorder(BorderFactory.createEmptyBorder(15, 5, 10, 5));
        add(heading, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Student Details"));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 6, 6, 6);
        g.anchor = GridBagConstraints.WEST;
        addField(form, g, 0, 0, "Register No:", regField);
        addField(form, g, 2, 0, "Student Name:", nameField);
        addField(form, g, 0, 1, "Java:", javaField);
        addField(form, g, 2, 1, "Maths:", mathsField);
        addField(form, g, 4, 1, "English:", englishField);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 8));
        JButton addBtn = new JButton("Add Student");
        JButton updateBtn = new JButton("Update Selected");
        JButton deleteBtn = new JButton("Delete Selected");
        JButton searchBtn = new JButton("Search");
        JButton clearBtn = new JButton("Clear");
        JButton refreshBtn = new JButton("Refresh");
        buttons.add(addBtn); buttons.add(updateBtn); buttons.add(deleteBtn);
        buttons.add(searchBtn); buttons.add(clearBtn); buttons.add(refreshBtn);

        JPanel top = new JPanel(new BorderLayout());
        top.add(form, BorderLayout.CENTER);
        top.add(buttons, BorderLayout.SOUTH);
        add(top, BorderLayout.BEFORE_FIRST_LINE);

        table.setRowHeight(25);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(table), BorderLayout.CENTER);
        status.setBorder(BorderFactory.createEmptyBorder(5, 10, 8, 10));
        add(status, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> addStudent());
        updateBtn.addActionListener(e -> updateStudent());
        deleteBtn.addActionListener(e -> deleteStudent());
        searchBtn.addActionListener(e -> searchStudent());
        clearBtn.addActionListener(e -> clearFields());
        refreshBtn.addActionListener(e -> loadStudents());

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                int r = table.getSelectedRow();
                regField.setText(model.getValueAt(r, 0).toString());
                nameField.setText(model.getValueAt(r, 1).toString());
                javaField.setText(model.getValueAt(r, 2).toString());
                mathsField.setText(model.getValueAt(r, 3).toString());
                englishField.setText(model.getValueAt(r, 4).toString());
            }
        });

        loadStudents();
    }

    private void addField(JPanel p, GridBagConstraints g, int x, int y, String label, JTextField field) {
        g.gridx = x; g.gridy = y; p.add(new JLabel(label), g);
        g.gridx = x + 1; p.add(field, g);
    }

    private int[] readMarks() {
        try {
            int a = Integer.parseInt(javaField.getText().trim());
            int b = Integer.parseInt(mathsField.getText().trim());
            int c = Integer.parseInt(englishField.getText().trim());
            if (a < 0 || a > 100 || b < 0 || b > 100 || c < 0 || c > 100)
                throw new IllegalArgumentException("Marks must be between 0 and 100.");
            return new int[]{a, b, c};
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Enter valid numeric marks for all subjects.");
        }
    }

    private String grade(double avg) {
        if (avg >= 90) return "A+";
        if (avg >= 80) return "A";
        if (avg >= 70) return "B";
        if (avg >= 60) return "C";
        if (avg >= 50) return "D";
        return "F";
    }

    private String[] makeRow(String reg, String name, int[] m) {
        int total = m[0] + m[1] + m[2];
        double avg = total / 3.0;
        return new String[]{reg, name, ""+m[0], ""+m[1], ""+m[2],
            ""+total, String.format(Locale.US, "%.2f", avg), grade(avg)};
    }

    private boolean validIdentity() {
        if (regField.getText().trim().isEmpty() || nameField.getText().trim().isEmpty()) {
            showError("Register number and student name are required."); return false;
        }
        return true;
    }

    private void addStudent() {
        try {
            if (!validIdentity()) return;
            String reg = regField.getText().trim();
            for (int i=0; i<model.getRowCount(); i++) {
                if (model.getValueAt(i,0).toString().equalsIgnoreCase(reg)) {
                    showError("This register number already exists."); return;
                }
            }
            int[] marks = readMarks();
            String[] row = makeRow(reg, nameField.getText().trim(), marks);
            appendCsv(row);
            model.addRow(row);
            status.setText("Student record added successfully.");
            clearFields();
        } catch (IllegalArgumentException ex) { showError(ex.getMessage()); }
        catch (IOException ex) { showError("Unable to save CSV file: " + ex.getMessage()); }
    }

    private void updateStudent() {
        int r = table.getSelectedRow();
        if (r < 0) { showError("Select a student record to update."); return; }
        try {
            if (!validIdentity()) return;
            int[] marks = readMarks();
            String[] row = makeRow(regField.getText().trim(), nameField.getText().trim(), marks);
            model.removeRow(r);
            model.insertRow(r, row);
            saveAll();
            status.setText("Student record updated successfully.");
            clearFields();
        } catch (IllegalArgumentException ex) { showError(ex.getMessage()); }
        catch (IOException ex) { showError("Unable to update CSV file: " + ex.getMessage()); }
    }

    private void deleteStudent() {
        int r = table.getSelectedRow();
        if (r < 0) { showError("Select a student record to delete."); return; }
        int choice = JOptionPane.showConfirmDialog(this, "Delete selected student record?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            model.removeRow(r);
            try { saveAll(); status.setText("Student record deleted."); clearFields(); }
            catch (IOException ex) { showError("Unable to save changes: " + ex.getMessage()); }
        }
    }

    private void searchStudent() {
        String key = JOptionPane.showInputDialog(this, "Enter register number or student name:");
        if (key == null || key.trim().isEmpty()) return;
        for (int i=0; i<model.getRowCount(); i++) {
            String reg = model.getValueAt(i,0).toString();
            String name = model.getValueAt(i,1).toString();
            if (reg.equalsIgnoreCase(key.trim()) || name.toLowerCase().contains(key.trim().toLowerCase())) {
                table.setRowSelectionInterval(i,i);
                table.scrollRectToVisible(table.getCellRect(i,0,true));
                status.setText("Matching student found.");
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "No matching student found.");
    }

    private void clearFields() {
        regField.setText(""); nameField.setText(""); javaField.setText("");
        mathsField.setText(""); englishField.setText(""); table.clearSelection();
    }

    private void loadStudents() {
        model.setRowCount(0);
        Path path = Paths.get(FILE_NAME);
        if (!Files.exists(path)) { status.setText("No CSV file yet. Add a student to create it."); return; }
        try (BufferedReader br = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String line; boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first && line.startsWith("Register No,")) { first = false; continue; }
                first = false;
                List<String> cells = parseCsvLine(line);
                if (cells.size() == 8) model.addRow(cells.toArray(new String[0]));
            }
            status.setText("Records loaded from " + path.toAbsolutePath());
        } catch (IOException ex) { showError("Unable to read CSV file: " + ex.getMessage()); }
    }

    private void appendCsv(String[] row) throws IOException {
        boolean newFile = !Files.exists(Paths.get(FILE_NAME));
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(FILE_NAME), StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            if (newFile) bw.write("Register No,Student Name,Java,Maths,English,Total,Average,Grade\n");
            bw.write(csv(row)); bw.newLine();
        }
    }

    private void saveAll() throws IOException {
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(FILE_NAME), StandardCharsets.UTF_8)) {
            bw.write("Register No,Student Name,Java,Maths,English,Total,Average,Grade\n");
            for (int i=0; i<model.getRowCount(); i++) {
                String[] row = new String[model.getColumnCount()];
                for (int j=0; j<row.length; j++) row[j] = model.getValueAt(i,j).toString();
                bw.write(csv(row)); bw.newLine();
            }
        }
    }

    private String csv(String[] values) {
        StringJoiner join = new StringJoiner(",");
        for (String value : values) join.add("\"" + value.replace("\"", "\"\"") + "\"");
        return join.toString();
    }

    private List<String> parseCsvLine(String line) {
        List<String> result = new ArrayList<>();
        StringBuilder cell = new StringBuilder();
        boolean quoted = false;
        for (int i=0; i<line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"') {
                if (quoted && i+1 < line.length() && line.charAt(i+1) == '"') { cell.append('"'); i++; }
                else quoted = !quoted;
            } else if (ch == ',' && !quoted) {
                result.add(cell.toString()); cell.setLength(0);
            } else cell.append(ch);
        }
        result.add(cell.toString());
        return result;
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Input / File Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new StudentMarksManagementSystem().setVisible(true));
    }
}
